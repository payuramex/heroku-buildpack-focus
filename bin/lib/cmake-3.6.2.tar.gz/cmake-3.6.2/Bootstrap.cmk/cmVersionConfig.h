#define CMake_VERSION_MAJOR 3
#define CMake_VERSION_MINOR 6
#define CMake_VERSION_PATCH 2
#define CMake_VERSION "3.6.2"
