TARGET_ARCHIVES_MAY_BE_SHARED_LIBS
----------------------------------

Set if shared libraries may be named like archives.

On AIX shared libraries may be named "lib<name>.a".  This property is
set to true on such platforms.
