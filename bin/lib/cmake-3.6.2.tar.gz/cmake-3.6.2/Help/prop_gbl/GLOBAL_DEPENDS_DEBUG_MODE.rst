GLOBAL_DEPENDS_DEBUG_MODE
-------------------------

Enable global target dependency graph debug mode.

CMake automatically analyzes the global inter-target dependency graph
at the beginning of native build system generation.  This property
causes it to display details of its analysis to stderr.
