VS_SHADER_FLAGS
---------------

Set additional VS shader flags of a ``.hlsl`` source file.
