CMAKE_AUTOUIC
-------------

Whether to handle ``uic`` automatically for Qt targets.

This variable is used to initialize the :prop_tgt:`AUTOUIC` property on all
the targets.  See that target property for additional information.
