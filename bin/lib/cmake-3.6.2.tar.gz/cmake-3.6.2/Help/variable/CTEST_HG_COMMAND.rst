CTEST_HG_COMMAND
----------------

Specify the CTest ``HGCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
