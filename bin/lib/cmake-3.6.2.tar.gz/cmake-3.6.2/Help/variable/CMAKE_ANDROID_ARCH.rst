CMAKE_ANDROID_ARCH
------------------

Default value for the :prop_tgt:`ANDROID_ARCH` target property.
See that target property for additional information.
