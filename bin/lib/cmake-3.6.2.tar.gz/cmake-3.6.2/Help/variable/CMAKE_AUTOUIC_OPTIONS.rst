CMAKE_AUTOUIC_OPTIONS
---------------------

Whether to handle ``uic`` automatically for Qt targets.

This variable is used to initialize the :prop_tgt:`AUTOUIC_OPTIONS` property on
all the targets.  See that target property for additional information.
