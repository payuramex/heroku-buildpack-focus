CMAKE_AUTORCC_OPTIONS
---------------------

Whether to handle ``rcc`` automatically for Qt targets.

This variable is used to initialize the :prop_tgt:`AUTORCC_OPTIONS` property on
all the targets.  See that target property for additional information.
