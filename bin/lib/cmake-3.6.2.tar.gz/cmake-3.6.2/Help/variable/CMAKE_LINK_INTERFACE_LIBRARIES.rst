CMAKE_LINK_INTERFACE_LIBRARIES
------------------------------

Default value for :prop_tgt:`LINK_INTERFACE_LIBRARIES` of targets.

This variable is used to initialize the :prop_tgt:`LINK_INTERFACE_LIBRARIES`
property on all the targets.  See that target property for additional
information.
