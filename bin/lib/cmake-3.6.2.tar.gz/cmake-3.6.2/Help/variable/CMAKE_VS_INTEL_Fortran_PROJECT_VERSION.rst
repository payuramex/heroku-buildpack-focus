CMAKE_VS_INTEL_Fortran_PROJECT_VERSION
--------------------------------------

When generating for :generator:`Visual Studio 7` or greater with the Intel
Fortran plugin installed, this specifies the ``.vfproj`` project file format
version.  This is intended for internal use by CMake and should not be
used by project code.
